export const exactBundleTabsData = [
    {
        id: 1,
        name: 'Items',
        value: 'items',
    },
    {
        id: 2,
        name: 'Documents',
        value: 'documents',
    },
]
