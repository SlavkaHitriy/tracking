export const trackingDataTabData = [
    {
        id: 1,
        name: 'F-0x007ca4 (Bundle 01)',
        value: 0,
    },
    {
        id: 2,
        name: 'F-0x007ca4 (Bundle 02)',
        value: 1,
    },
    {
        id: 3,
        name: 'F-0x007ca4 (Bundle 03)',
        value: 2,
    },
    {
        id: 4,
        name: 'F-0x007ca4 (Bundle 04)',
        value: 3,
    },
    {
        id: 5,
        name: 'F-0x007ca4 (Bundle 05)',
        value: 4,
    },
]
