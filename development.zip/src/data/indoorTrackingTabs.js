export const indoorTrackingTabsData = [
    {
        id: 1,
        name: 'Overview',
        value: 'overview',
    },
    {
        id: 2,
        name: 'History',
        value: 'history',
    },
    {
        id: 3,
        name: 'Notes',
        value: 'notes',
    },
    {
        id: 4,
        name: 'Attachments',
        value: 'attachments',
    },
    {
        id: 5,
        name: 'Device Data',
        value: 'deviceData',
    },
]
