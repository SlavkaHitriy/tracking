export const briefInfoProgressData = [
    {
        id: 1,
        name: 'Status',
        value: 'In Route',
        status: 2,
        date: '12/01/22',
        time: '08:57AM',
    },
    {
        id: 2,
        name: 'Total Trip',
        value: '3 Days 4 hrs',
        status: 1,
        date: '12/05/22',
        time: '08:57AM',
    },
]
