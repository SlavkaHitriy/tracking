export const globalTrackingTabsData = [
    {
        id: 1,
        name: 'Overview',
        value: 'overview',
    },
    {
        id: 2,
        name: 'Bundles',
        value: 'bundles',
    },
    {
        id: 3,
        name: 'Notes',
        value: 'notes',
    },
    {
        id: 4,
        name: 'Attachments',
        value: 'attachments',
    },
    {
        id: 5,
        name: 'Tracking Data',
        value: 'trackingData',
    },
]
