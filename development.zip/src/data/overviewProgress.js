export const overviewProgressData = [
    {
        id: 1,
        name: 'Job Setup',
        value: 'Complete',
        status: 2,
        date: '12/01/22',
        time: '08:57AM',
    },
    {
        id: 2,
        name: 'Documents',
        value: 'Complete',
        status: 2,
        date: '12/05/22',
        time: '08:57AM',
    },
    {
        id: 3,
        name: 'Preparation',
        value: 'Complete',
        status: 2,
        date: '12/05/22',
        time: '08:57AM',
    },
    {
        id: 4,
        name: 'Shipping',
        value: 'Ready',
        status: 1,
        date: '12/05/22',
        time: '08:57AM',
    },
]
