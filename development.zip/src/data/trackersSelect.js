export const trackersSelectData = [
    {
        id: 1,
        name: 'Tracker 1',
        value: 0,
    },
    {
        id: 2,
        name: 'Tracker 2',
        value: 1,
    },
    {
        id: 3,
        name: 'Tracker 3',
        value: 2,
    },
    {
        id: 4,
        name: 'Tracker 4',
        value: 3,
    },
]
