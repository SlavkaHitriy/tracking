export const newEntryProgressData = [
    {
        id: 1,
        name: 'Job Setup',
        value: 'None',
        status: 1,
        date: '12/01/22',
        time: '08:57AM',
    },
    {
        id: 2,
        name: 'Documents',
        value: 'Pending',
        status: 0,
        date: '12/01/22',
        time: '08:57AM',
    },
    {
        id: 3,
        name: 'Preparation',
        value: 'Pending',
        status: 0,
        date: '12/01/22',
        time: '08:57AM',
    },
    {
        id: 4,
        name: 'Shipping',
        value: 'Pending',
        status: 0,
        date: '12/01/22',
        time: '08:57AM',
    },
]
