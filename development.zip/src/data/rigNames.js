export const rigNamesData = [
    {
        id: 1,
        name: 'Ocean Rig 107',
        value: 0,
    },
    {
        id: 2,
        name: 'Ocean Rig 108',
        value: 1,
    },
    {
        id: 3,
        name: 'Ocean Rig 109',
        value: 2,
    },
    {
        id: 4,
        name: 'Ocean Rig 110',
        value: 3,
    },
]
