export const dataTypesData = [
    {
        id: 1,
        name: 'Trip Data',
        value: 'trip',
    },
    {
        id: 2,
        name: 'Satellite Data',
        value: 'satellite',
    },
]
