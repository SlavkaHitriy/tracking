export const statusSelectData = [
    {
        id: 1,
        name: 'Select User',
        value: 0,
    },
    {
        id: 2,
        name: 'Status 2',
        value: 1,
    },
    {
        id: 3,
        name: 'Status 3',
        value: 2,
    },
]
