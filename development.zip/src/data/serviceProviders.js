export const serviceProvidersData = [
    {
        id: 1,
        name: 'Black Diamond',
        value: 0,
    },
    {
        id: 2,
        name: 'Black Diamond 1',
        value: 1,
    },
    {
        id: 3,
        name: 'Black Diamond 2',
        value: 2,
    },
]
