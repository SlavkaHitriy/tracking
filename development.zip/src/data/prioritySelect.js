export const prioritySelectData = [
    {
        id: 1,
        name: 'Normal (default)',
        value: 0,
    },
    {
        id: 2,
        name: 'Not urgent',
        value: 1,
    },
    {
        id: 3,
        name: 'Urgent',
        value: 2,
    },
]
