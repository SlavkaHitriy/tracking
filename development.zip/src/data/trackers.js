export const trackersData = [
    {
        id: 1,
        name: 'Total Trackers',
        count: 23,
        color: '#9E9E9E',
    },
    {
        id: 2,
        name: 'Ready',
        count: 1,
        color: '#262B40',
    },
    {
        id: 3,
        name: 'Tracking',
        count: 10,
        color: '#19A872',
    },
    {
        id: 4,
        name: 'Completed',
        count: 2,
        color: '#0061FF',
    },
]
