export const shipmentsData = [
    {
        id: 1,
        name: 'Shipment 101',
        status: 2,
        date: '11/01/22 12:23PM',
    },
    {
        id: 2,
        name: 'Shipment 102',
        status: 1,
        date: '11/01/22 12:33PM',
    },
    {
        id: 3,
        name: 'Shipment 103',
        status: 2,
        date: '11/01/22 12:23PM',
    },
    {
        id: 4,
        name: 'Shipment 104',
        status: 2,
        date: '11/01/22 12:23PM',
    },
    {
        id: 5,
        name: 'Shipment 105',
        status: 4,
        date: '11/01/22 12:23PM',
    },
    {
        id: 6,
        name: 'Shipment 106',
        status: 2,
        date: '11/01/22 12:23PM',
    },
    {
        id: 7,
        name: 'Shipment 099',
        status: 3,
        date: '11/01/22 12:23PM',
    },
]
