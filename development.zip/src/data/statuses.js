export const statusesData = [
    {
        id: 1,
        name: 'All status',
        value: 0,
    },
    {
        id: 2,
        name: 'Ready',
        value: 1,
    },
    {
        id: 3,
        name: 'Tracking',
        value: 2,
    },
    {
        id: 4,
        name: 'Completed',
        value: 3,
    },
    {
        id: 5,
        name: 'Documentation',
        value: 4,
    },
]
