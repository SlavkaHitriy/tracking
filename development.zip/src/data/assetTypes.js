export const assetTypesData = [
    {
        id: 1,
        name: 'Drill Pipe',
        value: 0,
    },
    {
        id: 2,
        name: 'Drill Pipe 1',
        value: 1,
    },
    {
        id: 3,
        name: 'Drill Pipe 2',
        value: 2,
    },
    {
        id: 4,
        name: 'Drill Pipe 3',
        value: 3,
    },
    {
        id: 5,
        name: 'Drill Pipe 4',
        value: 4,
    },
]
