import React from 'react'

// Components
import { MainRoutes } from './routes/MainRoutes'

export const App = () => {
    return <MainRoutes/>
}
